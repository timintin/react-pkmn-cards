import React from "react";
import CardTable from "./CardTable";

function App() {
  return (
    <CardTable />
  );
}

export default App;
