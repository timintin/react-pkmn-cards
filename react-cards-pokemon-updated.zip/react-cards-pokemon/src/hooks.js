
import { useState } from 'react';

// Custom hook for flipping a card
function useFlip() {
  const [isFlipped, setIsFlipped] = useState(false);

  function flipCard() {
    setIsFlipped(isFlipped => !isFlipped);
  }

  return [isFlipped, flipCard];
}

export { useFlip };

import { useState, useEffect } from 'react';
import axios from 'axios';

// Custom hook for making API requests using Axios
function useAxios(url) {
  const [data, setData] = useState([]);
  const [addData, setAddData] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const response = await axios.get(url);
      setData(response.data);
    }
    fetchData();
  }, [url]);

  const addNewData = async (newUrl) => {
    const response = await axios.get(newUrl);
    setAddData(data => [...data, response.data]);
  };

  return [data, addNewData];
}

export { useFlip, useAxios };
