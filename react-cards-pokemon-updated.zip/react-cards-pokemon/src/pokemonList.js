/* list of common pokemon for the PokemonSelect component. */
const pokemon = [
  "pikachu",
  "jigglypuff",
  "charizard",
  "gengar",
  "arcanine",
  "bulbasaur",
  "blaziken",
  "umbreon",
  "lucario",
  "gardevoir",
  "eevee",
  "dragonite",
  "absol",
  "typhlosion",
  "ampharos",
  "squirtle",
  "flygon",
  "ninetales",
  "tyranitar",
  "infernape",
  "snorlax",
  "torterra",
  "luxray",
  "scizor",
  "blastoise",
  "mudkip",
  "garchomp"
];

export default pokemon;
